# ITSEGPT
Azure bot con chat GPT by ITSE
